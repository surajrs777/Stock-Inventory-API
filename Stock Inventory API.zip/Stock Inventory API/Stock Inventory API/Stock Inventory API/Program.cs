using Microsoft.EntityFrameworkCore;
using Stock_Inventory_API.Model;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// Register DbContext with dependency injection
builder.Services.AddDbContext<StockDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add services to the container (controllers, etc.)
builder.Services.AddControllers(); // Registers controllers in the DI container to handle API requests // Controllers ko services me register karna zaroori hai

// Register Swagger services
builder.Services.AddEndpointsApiExplorer();  // This is needed for Swagger to work
builder.Services.AddSwaggerGen();  // This adds Swagger generation

var app = builder.Build();

// Configure the HTTP request pipeline.

// Enable Swagger middleware to generate the Swagger JSON and Swagger UI
app.UseSwagger();  // This enables the Swagger JSON endpoint

// Enable Swagger UI at the root URL (or change the route as needed)
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();   // Enables Swagger for API documentation in development mode
    app.UseSwaggerUI(); // Enables Swagger UI for interactive API testing
}

// Add HTTPS Redirection (Optional but recommended)
app.UseHttpsRedirection(); // Redirect HTTP requests to HTTPS for secure communication

app.MapControllers(); // Controllers ke routes ko map karna

app.UseRouting(); // Configure request routing to map URLs to the correct controllers. // Routing enable karna

app.MapControllers(); // Enable controllers to handle API requests based on defined routes

// Add a simple weather forecast route (this is optional and can be removed if not needed)
var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};

app.MapGet("/weatherforecast", () =>
{
    var forecast = Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        ))
        .ToArray();
    return forecast;
});

app.Run();

// A simple WeatherForecast record, used for the weather API route above
internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}