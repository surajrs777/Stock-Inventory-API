﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stock_Inventory_API.Model;

namespace Stock_Inventory_API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseController : ControllerBase
    {
        private readonly StockDbContext _context;

        public PurchaseController(StockDbContext context)
        {
            _context = context;
        }

        // ---------------- CREATE (POST) ----------------
        [HttpPost]
        public IActionResult CreateNewPurchase(PurchaseViewModel obj)
        {
            try
            {
                PurchaseTbl _pur = new PurchaseTbl()
                {
                    invoiceNo = obj.invoiceNo,
                    purchaseDate = obj.purchaseDate,
                    supplierId = obj.supplierId
                };
                _context.PurchaseTbl.Add(_pur);
                _context.SaveChanges();

                foreach (var item in obj.PurchaseDetails)
                {
                    PurchaseDetailTbl _detail = new PurchaseDetailTbl()
                    {
                        productId = item.productId,
                        purchaseCost = item.purchaseCost,
                        purchaseId = _pur.purchaseId,
                        quantity = item.quantity,
                    };
                    _context.PurchaseDetailTbls.Add(_detail);
                    _context.SaveChanges();

                    var isStockExist = _context.StockTbls.SingleOrDefault(m => m.productId == item.productId);
                    if (isStockExist == null)
                    {
                        StockTbl _stock = new StockTbl()
                        {
                            createdDate = DateTime.Now,
                            lastUpdateDate = DateTime.Now,
                            productId = item.productId,
                            quantity = item.quantity
                        };
                        _context.StockTbls.Add(_stock);
                        _context.SaveChanges();
                    }
                    else
                    {
                        isStockExist.quantity += item.quantity;
                        isStockExist.lastUpdateDate = DateTime.Now;
                        _context.SaveChanges();
                    }
                }

                return Created("", obj);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while creating purchase", error = ex.Message });
            }
        }

        // ---------------- READ (GET ALL) ----------------
        [HttpGet]
        public IActionResult GetAllPurchases()
        {
            try
            {
                var purchases = _context.PurchaseTbl.ToList();
                return Ok(purchases);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching purchases", error = ex.Message });
            }
        }

        // ---------------- READ (GET BY ID) ----------------
        [HttpGet("{id}")]
        public IActionResult GetPurchaseById(int id)
        {
            try
            {
                var purchase = _context.PurchaseTbl.SingleOrDefault(p => p.purchaseId == id);
                if (purchase == null)
                    return NotFound(new { message = "Purchase not found" });

                return Ok(purchase);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching purchase", error = ex.Message });
            }
        }

        // ---------------- UPDATE (PUT) ----------------
        [HttpPut("{id}")]
        public IActionResult UpdatePurchase(int id, PurchaseViewModel obj)
        {
            try
            {
                var existingPurchase = _context.PurchaseTbl.SingleOrDefault(p => p.purchaseId == id);
                if (existingPurchase == null)
                    return NotFound(new { message = "Purchase not found" });

                existingPurchase.invoiceNo = obj.invoiceNo;
                existingPurchase.purchaseDate = obj.purchaseDate;
                existingPurchase.supplierId = obj.supplierId;

                _context.SaveChanges();

                return Ok(existingPurchase);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while updating purchase", error = ex.Message });
            }
        }

        // ---------------- DELETE ----------------
        [HttpDelete("{id}")]
        public IActionResult DeletePurchase(int id)
        {
            try
            {
                var purchase = _context.PurchaseTbl.SingleOrDefault(p => p.purchaseId == id);
                if (purchase == null)
                    return NotFound(new { message = "Purchase not found" });

                _context.PurchaseTbl.Remove(purchase);
                _context.SaveChanges();

                return Ok(new { message = "Purchase deleted successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while deleting purchase", error = ex.Message });
            }
        }
    }
}
