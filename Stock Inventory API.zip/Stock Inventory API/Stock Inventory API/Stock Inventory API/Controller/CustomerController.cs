﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stock_Inventory_API.Model;

namespace Stock_Inventory_API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly StockDbContext _context;

        public CustomerController(StockDbContext context)
        {
            _context = context;
        }

        // ---------------- READ (GET ALL) ----------------
        [HttpGet]
        public IActionResult GetAllCustomers()
        {
            try
            {
                var customers = _context.CustomerTbls.ToList();
                return Ok(customers);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching customers", error = ex.Message });
            }
        }

        // ---------------- CREATE (POST) ----------------
        [HttpPost]
        public IActionResult CreateCustomer([FromBody] CustomerTbl obj)
        {
            try
            {
                _context.CustomerTbls.Add(obj);
                _context.SaveChanges();
                return Created("", obj);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while creating customer", error = ex.Message });
            }
        }

        // ---------------- READ (GET BY ID) ----------------
        [HttpGet("{id}")]
        public IActionResult GetCustomerById(int id)
        {
            try
            {
                var customer = _context.CustomerTbls.SingleOrDefault(c => c.customerId == id);
                if (customer == null)
                    return NotFound(new { message = "Customer not found" });

                return Ok(customer);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching customer", error = ex.Message });
            }
        }

        // ---------------- UPDATE (PUT) ----------------
        [HttpPut("{id}")]
        public IActionResult UpdateCustomer(int id, [FromBody] CustomerTbl obj)
        {
            try
            {
                var existingCustomer = _context.CustomerTbls.SingleOrDefault(c => c.customerId == id);
                if (existingCustomer == null)
                    return NotFound(new { message = "Customer not found" });

                existingCustomer.name = obj.name;
                existingCustomer.mobile = obj.mobile;
                existingCustomer.address = obj.address;

                _context.SaveChanges();

                return Ok(existingCustomer);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while updating customer", error = ex.Message });
            }
        }

        // ---------------- DELETE ----------------
        [HttpDelete("{id}")]
        public IActionResult DeleteCustomer(int id)
        {
            try
            {
                var customer = _context.CustomerTbls.SingleOrDefault(c => c.customerId == id);
                if (customer == null)
                    return NotFound(new { message = "Customer not found" });

                _context.CustomerTbls.Remove(customer);
                _context.SaveChanges();

                return Ok(new { message = "Customer deleted successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while deleting customer", error = ex.Message });
            }
        }
    }
}
