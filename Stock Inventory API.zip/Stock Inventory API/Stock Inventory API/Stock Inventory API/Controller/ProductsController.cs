﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stock_Inventory_API.Model;

namespace Stock_Inventory_API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly StockDbContext _context;

        public ProductsController(StockDbContext context)
        {
            _context = context;
        }

        // ---------------- READ (GET ALL) ----------------
        [HttpGet]
        public IActionResult GetAllProducts()
        {
            try
            {
                var products = _context.ProductsTbls.ToList();
                return Ok(products);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching products", error = ex.Message });
            }
        }

        // ---------------- CREATE (POST) ----------------
        [HttpPost]
        public IActionResult CreateProduct([FromBody] ProductsTbl obj)
        {
            try
            {
                obj.createdDate = DateTime.Now; // Auto-assign createdDate
                _context.ProductsTbls.Add(obj);
                _context.SaveChanges();
                return Created("", obj);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while creating product", error = ex.Message });
            }
        }

        // ---------------- READ (GET BY ID) ----------------
        [HttpGet("{id}")]
        public IActionResult GetProductById(int id)
        {
            try
            {
                var product = _context.ProductsTbls.SingleOrDefault(p => p.productId == id);
                if (product == null)
                    return NotFound(new { message = "Product not found" });

                return Ok(product);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching product", error = ex.Message });
            }
        }

        // ---------------- UPDATE (PUT) ----------------
        [HttpPut("{id}")]
        public IActionResult UpdateProduct(int id, [FromBody] ProductsTbl obj)
        {
            try
            {
                var existingProduct = _context.ProductsTbls.SingleOrDefault(p => p.productId == id);
                if (existingProduct == null)
                    return NotFound(new { message = "Product not found" });

                existingProduct.categoryId = obj.categoryId;
                existingProduct.productName = obj.productName;
                existingProduct.basicPrice = obj.basicPrice;
                existingProduct.description = obj.description;
                existingProduct.companyName = obj.companyName;
                existingProduct.createdDate = DateTime.Now; // Update createdDate to current time

                _context.SaveChanges();

                return Ok(existingProduct);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while updating product", error = ex.Message });
            }
        }

        // ---------------- DELETE ----------------
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int id)
        {
            try
            {
                var product = _context.ProductsTbls.SingleOrDefault(p => p.productId == id);
                if (product == null)
                    return NotFound(new { message = "Product not found" });

                _context.ProductsTbls.Remove(product);
                _context.SaveChanges();

                return Ok(new { message = "Product deleted successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while deleting product", error = ex.Message });
            }
        }
    }
}
