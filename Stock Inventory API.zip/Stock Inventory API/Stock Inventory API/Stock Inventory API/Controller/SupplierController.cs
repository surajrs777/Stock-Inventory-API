﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stock_Inventory_API.Model;

namespace Stock_Inventory_API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly StockDbContext _context;

        public SupplierController(StockDbContext context)
        {
            _context = context;
        }

        // ---------------- READ (GET ALL) ----------------
        [HttpGet]
        public IActionResult GetAllSuppliers()
        {
            try
            {
                var suppliers = _context.SupplierTbl.ToList();
                return Ok(suppliers);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching suppliers", error = ex.Message });
            }
        }

        // ---------------- CREATE (POST) ----------------
        [HttpPost]
        public IActionResult CreateSupplier([FromBody] SupplierTbl obj)
        {
            try
            {
                _context.SupplierTbl.Add(obj);
                _context.SaveChanges();
                return Created("", obj);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while creating supplier", error = ex.Message });
            }
        }

        // ---------------- READ (GET BY ID) ----------------
        [HttpGet("{id}")]
        public IActionResult GetSupplierById(int id)
        {
            try
            {
                var supplier = _context.SupplierTbl.SingleOrDefault(s => s.supplierId == id);
                if (supplier == null)
                    return NotFound(new { message = "Supplier not found" });

                return Ok(supplier);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching supplier", error = ex.Message });
            }
        }

        // ---------------- UPDATE (PUT) ----------------
        [HttpPut("{id}")]
        public IActionResult UpdateSupplier(int id, [FromBody] SupplierTbl obj)
        {
            try
            {
                var existingSupplier = _context.SupplierTbl.SingleOrDefault(s => s.supplierId == id);
                if (existingSupplier == null)
                    return NotFound(new { message = "Supplier not found" });

                existingSupplier.supplierName = obj.supplierName;
                existingSupplier.mobileNo = obj.mobileNo;
                existingSupplier.emailId = obj.emailId;
                existingSupplier.gstNo = obj.gstNo;
                existingSupplier.address = obj.address;

                _context.SaveChanges();

                return Ok(existingSupplier);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while updating supplier", error = ex.Message });
            }
        }

        // ---------------- DELETE ----------------
        [HttpDelete("{id}")]
        public IActionResult DeleteSupplier(int id)
        {
            try
            {
                var supplier = _context.SupplierTbl.SingleOrDefault(s => s.supplierId == id);
                if (supplier == null)
                    return NotFound(new { message = "Supplier not found" });

                _context.SupplierTbl.Remove(supplier);
                _context.SaveChanges();

                return Ok(new { message = "Supplier deleted successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while deleting supplier", error = ex.Message });
            }
        }
    }
}
