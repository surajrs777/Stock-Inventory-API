﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Stock_Inventory_API.Model;

namespace Stock_Inventory_API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly StockDbContext _context;

        public CategoryController(StockDbContext context)
        {
            _context = context;
        }

        //[HttpGet("testdb")]
        //public IActionResult TestDatabaseConnection()
        //{
        //    try
        //    {
        //        string dbName = _context.Database.GetDbConnection().Database;
        //        return Ok(new { success = true, message = "Connected successfully!", database = dbName });
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, new { success = false, message = $"Database connection error: {ex.Message}" });
        //    }
        //}


        //[HttpGet]
        //public IActionResult GetCategories()
        //{
        //    try
        //    {
        //        var categories = _context.CategoryTbls.ToList();
        //        if (categories == null || !categories.Any())
        //        {
        //            return Ok(
        //                new
        //                {
        //                    success = false,
        //                    message = "No categories found.",
        //                    data = (object)null
        //                });  // 200 OK with message
        //            //return Ok(categories);
        //        }

        //        return Ok(
        //            new
        //            {
        //                success = true,
        //                message = "Categories retrieved successfully.",
        //                data = categories
        //            });  // 200 OK with data
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500,
        //            new
        //            {
        //                success = false,
        //                message = $"Internal server error: {ex.Message}",
        //                data = (object)null
        //            });  // 500 Internal Server Error
        //    }
        //}

        [HttpGet]
        public IActionResult GetCategories()
        {
            try
            {
                var categories = _context.CategoryTbls.ToList();
                if (!categories.Any())
                {
                    return Ok(new { success = false, message = "No categories found.", data = (object)null });
                }
                return Ok(new { success = true, message = "Categories retrieved successfully.", data = categories });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Internal server error: {ex.Message}", data = (object)null });
            }
        }

        // 🔹 GET CATEGORY BY ID
        [HttpGet("{id}")]
        public IActionResult GetCategoryById(int id)
        {
            try
            {
                var category = _context.CategoryTbls.Find(id);
                if (category == null)
                {
                    return NotFound(new { success = false, message = "Category not found.", data = (object)null });
                }
                return Ok(new { success = true, message = "Category retrieved successfully.", data = category });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Internal server error: {ex.Message}", data = (object)null });
            }
        }

        // 🔹 CREATE CATEGORY (POST)
        [HttpPost]
        public IActionResult CreateCategory(CategoryTbl category)
        {
            try
            {
                if (category == null || string.IsNullOrWhiteSpace(category.categoryName))
                {
                    return BadRequest(new { success = false, message = "Category name is required.", data = (object)null });
                }

                var newCategory = new CategoryTbl
                {
                    categoryName = category.categoryName
                };

                _context.CategoryTbls.Add(newCategory);
                _context.SaveChanges();

                return Ok(new { success = true, message = "Category added successfully.", data = newCategory });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Internal server error: {ex.Message}", data = (object)null });
            }
        }

        // 🔹 UPDATE CATEGORY (PUT)
        [HttpPut("{id}")]
        public IActionResult UpdateCategory(int id, CategoryTbl updatedCategory)
        {
            try
            {
                var category = _context.CategoryTbls.Find(id);
                if (category == null)
                {
                    return NotFound(new { success = false, message = "Category not found.", data = (object)null });
                }

                category.categoryName = updatedCategory.categoryName;
                _context.SaveChanges();

                return Ok(new { success = true, message = "Category updated successfully.", data = category });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Internal server error: {ex.Message}", data = (object)null });
            }
        }

        // 🔹 DELETE CATEGORY
        [HttpDelete("{id}")]
        public IActionResult DeleteCategory(int id)
        {
            try
            {
                var category = _context.CategoryTbls.Find(id);
                if (category == null)
                {
                    return NotFound(new { success = false, message = "Category not found.", data = (object)null });
                }

                _context.CategoryTbls.Remove(category);
                _context.SaveChanges();

                return Ok(new { success = true, message = "Category deleted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Internal server error: {ex.Message}", data = (object)null });
            }
        }
    }
}
