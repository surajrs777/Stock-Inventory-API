﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stock_Inventory_API.Model;

namespace Stock_Inventory_API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class SaleController : ControllerBase
    {
        private readonly StockDbContext _context;

        public SaleController(StockDbContext context)
        {
            _context = context;
        }

        // ---------------- CREATE (POST) ----------------
        [HttpPost]
        public IActionResult CreateNewSale(SaleViewModel obj)
        {
            try
            {
                SaleTbl _sale = new SaleTbl()
                {
                    invoiceNo = obj.invoiceNo,
                    customerId = obj.customerId,
                    naration = obj.naration,
                    saleDate = obj.saleDate,
                    totalAmount = obj.totalAmount
                };
                _context.SaleTbl.Add(_sale);
                _context.SaveChanges();

                foreach (var item in obj.SaleDetails)
                {
                    SaleDetailsTbl _detail = new SaleDetailsTbl()
                    {
                        productId = item.productId,
                        quantity = item.quantity,
                        saleAmount = item.saleAmount,
                        saleId = _sale.saleId
                    };
                    _context.SaleDetailsTbl.Add(_detail);
                    _context.SaveChanges();

                    var isStockExist = _context.StockTbls.SingleOrDefault(m => m.productId == item.productId);
                    if (isStockExist != null)
                    {
                        isStockExist.quantity -= item.quantity;
                        isStockExist.lastUpdateDate = DateTime.Now;
                        _context.SaveChanges();
                    }
                }

                return Created("", obj);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while creating sale", error = ex.Message });
            }
        }

        // ---------------- READ (GET ALL) ----------------
        [HttpGet]
        public IActionResult GetAllSales()
        {
            try
            {
                var sales = _context.SaleTbl.ToList();
                return Ok(sales);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching sales", error = ex.Message });
            }
        }

        // ---------------- READ (GET BY ID) ----------------
        [HttpGet("{id}")]
        public IActionResult GetSaleById(int id)
        {
            try
            {
                var sale = _context.SaleTbl.SingleOrDefault(s => s.saleId == id);
                if (sale == null)
                    return NotFound(new { message = "Sale not found" });

                return Ok(sale);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while fetching sale", error = ex.Message });
            }
        }

        // ---------------- UPDATE (PUT) ----------------
        [HttpPut("{id}")]
        public IActionResult UpdateSale(int id, SaleViewModel obj)
        {
            try
            {
                var existingSale = _context.SaleTbl.SingleOrDefault(s => s.saleId == id);
                if (existingSale == null)
                    return NotFound(new { message = "Sale not found" });

                existingSale.invoiceNo = obj.invoiceNo;
                existingSale.customerId = obj.customerId;
                existingSale.naration = obj.naration;
                existingSale.saleDate = obj.saleDate;
                existingSale.totalAmount = obj.totalAmount;

                _context.SaveChanges();

                return Ok(existingSale);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while updating sale", error = ex.Message });
            }
        }

        // ---------------- DELETE ----------------
        [HttpDelete("{id}")]
        public IActionResult DeleteSale(int id)
        {
            try
            {
                var sale = _context.SaleTbl.SingleOrDefault(s => s.saleId == id);
                if (sale == null)
                    return NotFound(new { message = "Sale not found" });

                _context.SaleTbl.Remove(sale);
                _context.SaveChanges();

                return Ok(new { message = "Sale deleted successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error while deleting sale", error = ex.Message });
            }
        }
    }
}
