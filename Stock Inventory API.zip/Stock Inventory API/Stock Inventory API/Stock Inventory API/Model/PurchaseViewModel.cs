﻿namespace Stock_Inventory_API.Model
{
    public class PurchaseViewModel
    {
        public int purchaseId { get; set; }
        public DateTime purchaseDate { get; set; }
        public int supplierId { get; set; }
        public string invoiceNo { get; set; }

        public List<PurchaseDetailTbl> PurchaseDetails { get; set; }
    }
}
