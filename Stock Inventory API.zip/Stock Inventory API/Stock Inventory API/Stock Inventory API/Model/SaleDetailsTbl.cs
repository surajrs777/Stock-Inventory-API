﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class SaleDetailsTbl
    {
        [Key]
        public int saleDetailId { get; set; }
        public int saleId { get; set; }
        public int productId { get; set; }
        public double saleAmount { get; set; }
        public int quantity { get; set; }
    }
}
