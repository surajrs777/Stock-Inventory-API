﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class SaleTbl
    {
        [Key]
        public int saleId { get; set; }
        public DateTime saleDate { get; set; }
        public double totalAmount { get; set; }
        public string invoiceNo { get; set; }
        public string naration { get; set; }
        public int customerId { get; set; }
    }
}
