﻿using Microsoft.EntityFrameworkCore;

namespace Stock_Inventory_API.Model
{
    public class StockDbContext : DbContext
    {
        public StockDbContext(DbContextOptions<StockDbContext> options) : base(options)
        {

        }
        public DbSet<CategoryTbl> CategoryTbls { get; set; }
        public DbSet<CustomerTbl> CustomerTbls { get; set; }
        public DbSet<ProductsTbl> ProductsTbls { get; set; }
        public DbSet<PurchaseDetailTbl> PurchaseDetailTbls { get; set; }
        public DbSet<PurchaseTbl> PurchaseTbl { get; set; }
        public DbSet<SaleDetailsTbl> SaleDetailsTbl { get; set; }

        public DbSet<SaleTbl> SaleTbl { get; set; }
        public DbSet<StockTbl> StockTbls { get; set; }
        public DbSet<SupplierTbl> SupplierTbl { get; set; }
    }
}
