﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class PurchaseDetailTbl
    {
        [Key]
        public int purchaseDetailId { get; set; }
        public int productId { get; set; }
        public int purchaseId { get; set; }
        public int quantity { get; set; }
        public double purchaseCost { get; set; }
    }
}
