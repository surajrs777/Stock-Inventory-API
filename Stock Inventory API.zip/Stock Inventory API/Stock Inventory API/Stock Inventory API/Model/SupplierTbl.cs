﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class SupplierTbl
    {
        [Key]
        public int supplierId { get; set; }
        public string supplierName { get; set; }
        public string mobileNo { get; set; }
        public string emailId { get; set; }
        public string gstNo { get; set; }
        public string address { get; set; }
    }
}
