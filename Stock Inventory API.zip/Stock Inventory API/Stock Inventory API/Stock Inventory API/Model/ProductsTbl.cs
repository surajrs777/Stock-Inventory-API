﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class ProductsTbl
    {
        [Key]
        public int productId { get; set; }
        public int categoryId { get; set; }
        public string productName { get; set; }
        public DateTime createdDate { get; set; }
        public double basicPrice { get; set; }
        public string description { get; set; }
        public string companyName { get; set; }
    }
}
