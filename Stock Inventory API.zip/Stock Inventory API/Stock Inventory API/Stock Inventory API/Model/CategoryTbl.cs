﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class CategoryTbl
    {
        [Key]
        public int categoryId { get; set; }
        [Required]
        public string categoryName { get; set; }
    }
}
