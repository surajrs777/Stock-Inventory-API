﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class StockTbl
    {
        [Key]
        public int stockId { get; set; }
        public int productId { get; set; }
        public int quantity { get; set; }
        public DateTime? createdDate { get; set; }
        public DateTime? lastUpdateDate { get; set; }
    }
}
