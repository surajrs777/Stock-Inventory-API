﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class CustomerTbl
    {
        [Key]
        public int customerId { get; set; }
        public string name { get; set; }
        public string mobile { get; set; }
        public string address { get; set; }
    }
}
