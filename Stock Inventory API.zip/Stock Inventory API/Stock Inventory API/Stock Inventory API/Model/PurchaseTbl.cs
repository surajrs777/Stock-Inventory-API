﻿using System.ComponentModel.DataAnnotations;

namespace Stock_Inventory_API.Model
{
    public class PurchaseTbl
    {
        [Key]
        public int purchaseId { get; set; }
        public DateTime purchaseDate { get; set; }
        public int supplierId { get; set; }
        public string invoiceNo { get; set; }
    }
}
